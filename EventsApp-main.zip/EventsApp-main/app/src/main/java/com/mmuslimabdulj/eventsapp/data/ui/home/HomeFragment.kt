package com.mmuslimabdulj.eventsapp.data.ui.home

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.snackbar.Snackbar
import com.mmuslimabdulj.eventsapp.data.ui.EventHorizontalAdapter
import com.mmuslimabdulj.eventsapp.data.ui.EventVerticalAdapter
import com.mmuslimabdulj.eventsapp.databinding.FragmentHomeBinding
import org.koin.androidx.viewmodel.ext.android.viewModel

class HomeFragment : Fragment() {

    private var _binding: FragmentHomeBinding? = null

    private val binding get() = _binding!!

    private val homeViewModel: HomeViewModel by viewModel()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.rvUpcomingEvents.layoutManager =
            LinearLayoutManager(requireContext(), LinearLayoutManager.HORIZONTAL, false)
        binding.rvFinishedEvents.layoutManager = LinearLayoutManager(requireContext())

        homeViewModel.activeEvents.observe(viewLifecycleOwner) { response ->
            response?.let {
                val eventList = it.listEvents
                val isEventListEmpty = eventList.isEmpty()
                binding.tvNoUpcomingEvents.visibility =
                    if (isEventListEmpty) View.VISIBLE else View.GONE
                binding.rvUpcomingEvents.visibility =
                    if (!isEventListEmpty) View.VISIBLE else View.GONE
                if (!isEventListEmpty) {
                    binding.rvUpcomingEvents.adapter = EventHorizontalAdapter(eventList)
                }
            }
        }

        homeViewModel.finishedEvents.observe(viewLifecycleOwner) { response ->
            response?.let {
                val eventList = it.listEvents
                binding.rvFinishedEvents.adapter = EventVerticalAdapter(eventList)
            }
        }

        homeViewModel.isLoading.observe(viewLifecycleOwner) {
            showLoading(it)
        }

        homeViewModel.errorMessage.observe(viewLifecycleOwner) { errorMessage ->
            errorMessage?.let {
                Snackbar.make(binding.root, it, Snackbar.LENGTH_LONG).show()
                homeViewModel.clearErrorMessage()
            }
        }
    }

    // To help refresh the RecyclerView when the network returns to normal
    // when moving from another Navigation to the Home Navigation.
    override fun onResume() {
        super.onResume()
        homeViewModel.fetchActiveEvents()
        homeViewModel.fetchFinishedEvents()
    }

    private fun showLoading(isLoading: Boolean) {
        binding.progressBar.visibility = if (isLoading) View.VISIBLE else View.GONE
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}