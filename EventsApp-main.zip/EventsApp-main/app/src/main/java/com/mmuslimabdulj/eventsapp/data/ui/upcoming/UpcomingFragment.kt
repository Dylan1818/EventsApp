package com.mmuslimabdulj.eventsapp.data.ui.upcoming

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.snackbar.Snackbar
import com.mmuslimabdulj.eventsapp.data.ui.EventVerticalAdapter
import com.mmuslimabdulj.eventsapp.databinding.FragmentUpcomingBinding
import org.koin.androidx.viewmodel.ext.android.viewModel

class UpcomingFragment : Fragment() {

    private var _binding: FragmentUpcomingBinding? = null

    private val binding get() = _binding!!

    private val upcomingViewModel: UpcomingViewModel by viewModel()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentUpcomingBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.rvFinishedEvents.layoutManager = LinearLayoutManager(requireContext())

        upcomingViewModel.upcomingEvents.observe(viewLifecycleOwner) { response ->
            response?.let {
                val eventList = it.listEvents
                val isEventListEmpty = eventList.isEmpty()
                binding.tvNoUpcomingEvents.visibility =
                    if (isEventListEmpty) View.VISIBLE else View.GONE
                binding.rvFinishedEvents.visibility =
                    if (!isEventListEmpty) View.VISIBLE else View.GONE
                if (!isEventListEmpty) {
                    binding.rvFinishedEvents.adapter = EventVerticalAdapter(eventList)
                }
            }
        }

        upcomingViewModel.isLoading.observe(viewLifecycleOwner) {
            showLoading(it)
        }

        upcomingViewModel.errorMessage.observe(viewLifecycleOwner) { errorMessage ->
            errorMessage?.let {
                Snackbar.make(binding.root, it, Snackbar.LENGTH_LONG).show()
                upcomingViewModel.clearErrorMessage()
            }
        }
    }

    // To help refresh the RecyclerView when the network returns to normal
    // when moving from another Navigation to the Home Navigation.
    override fun onResume() {
        super.onResume()
        upcomingViewModel.fetchUpcomingEvents()
    }

    private fun showLoading(isLoading: Boolean) {
        binding.progressBar.visibility = if (isLoading) View.VISIBLE else View.GONE
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}