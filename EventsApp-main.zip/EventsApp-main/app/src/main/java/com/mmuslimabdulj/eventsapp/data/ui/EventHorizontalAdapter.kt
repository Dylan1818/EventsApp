package com.mmuslimabdulj.eventsapp.data.ui

import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.google.android.material.snackbar.Snackbar
import com.mmuslimabdulj.eventsapp.R
import com.mmuslimabdulj.eventsapp.data.response.ListEventsItem
import com.mmuslimabdulj.eventsapp.data.ui.MainActivity.Companion.networkMonitor

class EventHorizontalAdapter(private val eventList: List<ListEventsItem>) :
    RecyclerView.Adapter<EventHorizontalAdapter.EventViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): EventViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_event_horizontal, parent, false)
        return EventViewHolder(view)
    }

    override fun getItemCount(): Int {
        return eventList.size
    }

    override fun onBindViewHolder(holder: EventViewHolder, position: Int) {
        val event = eventList[position]
        Glide.with(holder.eventImage.context)
            .load(event.imageLogo)
            .placeholder(R.drawable.placeholder)
            .into(holder.eventImage)

        holder.itemView.setOnClickListener {
            if (networkMonitor.isConnected.value == true) {
                val intent =
                    Intent(holder.itemView.context, DetailEventActivity::class.java).apply {
                        putExtra(DetailEventActivity.EXTRA_ID, event.id)
                    }
                holder.itemView.context.startActivity(intent)
            } else {
                Snackbar.make(
                    holder.itemView,
                    "Cannot be accessed due to network problems",
                    Snackbar.LENGTH_LONG
                ).show()
            }
        }
    }

    class EventViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val eventImage: ImageView = view.findViewById(R.id.img_event_poster_vertical)
    }
}