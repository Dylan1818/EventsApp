package com.mmuslimabdulj.eventsapp.data.di

import com.mmuslimabdulj.eventsapp.data.repository.EventsRepository
import com.mmuslimabdulj.eventsapp.data.retrofit.ApiConfig
import com.mmuslimabdulj.eventsapp.data.retrofit.ApiService
import com.mmuslimabdulj.eventsapp.data.ui.finished.FinishedViewModel
import com.mmuslimabdulj.eventsapp.data.ui.home.HomeViewModel
import com.mmuslimabdulj.eventsapp.data.ui.upcoming.UpcomingViewModel
import org.koin.androidx.viewmodel.dsl.viewModel
import org.koin.dsl.module

val appModule = module {

    single<ApiService> { ApiConfig.getApiService() }

    single { EventsRepository(get()) }

    viewModel { HomeViewModel(get()) }
    viewModel { UpcomingViewModel(get()) }
    viewModel { FinishedViewModel(get()) }
}