package com.mmuslimabdulj.eventsapp.data.ui

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.core.text.HtmlCompat
import com.bumptech.glide.Glide
import com.google.android.material.snackbar.Snackbar
import com.mmuslimabdulj.eventsapp.R
import com.mmuslimabdulj.eventsapp.data.repository.EventsRepository
import com.mmuslimabdulj.eventsapp.data.response.DetailEventResponse
import com.mmuslimabdulj.eventsapp.databinding.ActivityDetailEventBinding
import org.koin.android.ext.android.inject

class DetailEventActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDetailEventBinding

    private val eventsRepository: EventsRepository by inject()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailEventBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val eventId = intent.getIntExtra(EXTRA_ID, -1)
        if (eventId != -1) {
            fetchEventDetails(eventId)
        }
    }

    private fun fetchEventDetails(eventId: Int) {
        showLoading(true)
        eventsRepository.getDetailEvents(eventId.toString()) { response, error ->
            showLoading(false)
            if (response != null) {
                displayEventDetails(response)
            } else {
                error?.let {
                    Snackbar.make(binding.root, it, Snackbar.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun displayEventDetails(response: DetailEventResponse) {
        val event = response.event
        with(binding) {
            Glide.with(root.context)
                .load(event.mediaCover)
                .placeholder(R.drawable.placeholder)
                .into(binding.imgImageLogo)
            tvEventTitle.text = event.name
            tvEventSummary.text = event.summary
            tvEventQuota.text =
                getString(R.string.sisa_kuota, event.quota - event.registrants)
            tvBeginTime.text = event.beginTime
            tvEventDescription.text = HtmlCompat.fromHtml(
                event.description,
                HtmlCompat.FROM_HTML_MODE_LEGACY
            )
            tvEventOwner.text = event.ownerName
            btnRegister.setOnClickListener {
                val url = event.link
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
                startActivity(intent)
            }
        }
    }

    private fun showLoading(isLoading: Boolean) {
        binding.progressBar.visibility = if (isLoading) View.VISIBLE else View.GONE
    }

    companion object {
        const val EXTRA_ID = "event_id"
    }
}