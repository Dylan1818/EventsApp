package com.mmuslimabdulj.eventsapp.data.ui.upcoming

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.mmuslimabdulj.eventsapp.data.repository.EventsRepository
import com.mmuslimabdulj.eventsapp.data.response.EventsResponse

class UpcomingViewModel(private val repository: EventsRepository) : ViewModel() {

    private val _upcomingEvents = MutableLiveData<EventsResponse?>()
    val upcomingEvents: LiveData<EventsResponse?> = _upcomingEvents

    private val _errorMessage = MutableLiveData<String?>()
    val errorMessage: LiveData<String?> = _errorMessage

    val isLoading: LiveData<Boolean> = repository.isLoading

    init {
        fetchUpcomingEvents()
    }

    fun fetchUpcomingEvents() {
        repository.getEvents(active = 1, limit = 40) { response, error ->
            if (response != null) {
                _upcomingEvents.postValue(response)
            } else {
                _errorMessage.postValue(error)
            }
        }
    }

    fun clearErrorMessage() {
        _errorMessage.postValue(null)
    }
}