package com.mmuslimabdulj.eventsapp.data.repository

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.mmuslimabdulj.eventsapp.data.response.DetailEventResponse
import com.mmuslimabdulj.eventsapp.data.response.EventsResponse
import com.mmuslimabdulj.eventsapp.data.retrofit.ApiService
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class EventsRepository(private val apiService: ApiService) {

    private val _isLoading = MutableLiveData<Boolean>()
    val isLoading: LiveData<Boolean> = _isLoading

    fun getEvents(active: Int, limit: Int, callback: (EventsResponse?, String?) -> Unit) {
        _isLoading.postValue(true)
        apiService.getEvents(active, limit).enqueue(object : Callback<EventsResponse> {
            override fun onResponse(
                call: Call<EventsResponse>,
                response: Response<EventsResponse>
            ) {
                _isLoading.postValue(false)
                if (response.isSuccessful) {
                    callback(response.body(), null)
                } else {
                    callback(null, "Failed to load events")
                }
            }

            override fun onFailure(call: Call<EventsResponse>, t: Throwable) {
                _isLoading.postValue(false)
                callback(null, "Failed to load events")
            }
        })
    }

    fun getDetailEvents(id: String, callback: (DetailEventResponse?, String?) -> Unit) {
        _isLoading.postValue(true)
        apiService.getDetailEvent(id).enqueue(object : Callback<DetailEventResponse> {
            override fun onResponse(
                call: Call<DetailEventResponse>,
                response: Response<DetailEventResponse>
            ) {
                _isLoading.postValue(false)
                if (response.isSuccessful) {
                    callback(response.body(), null)
                } else {
                    callback(null, "Failed to load event details")
                }
            }

            override fun onFailure(call: Call<DetailEventResponse>, t: Throwable) {
                _isLoading.postValue(false)
                callback(null, "Failed to load event details")
            }
        })
    }

    fun getSearchEvents(active: Int, q: String, callback: (EventsResponse?, String?) -> Unit) {
        _isLoading.postValue(true)
        apiService.searchEvents(active, q).enqueue(object : Callback<EventsResponse> {
            override fun onResponse(
                call: Call<EventsResponse>,
                response: Response<EventsResponse>
            ) {
                _isLoading.postValue(false)
                if (response.isSuccessful) {
                    callback(response.body(), null)
                } else {
                    callback(null, "Failed to search events")
                }
            }

            override fun onFailure(call: Call<EventsResponse>, t: Throwable) {
                _isLoading.postValue(false)
                callback(null, "Failed to search events")
            }
        })
    }
}