package com.mmuslimabdulj.eventsapp.data.ui.finished

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.mmuslimabdulj.eventsapp.data.repository.EventsRepository
import com.mmuslimabdulj.eventsapp.data.response.EventsResponse

class FinishedViewModel(private val repository: EventsRepository) : ViewModel() {

    private val _finishedEvents = MutableLiveData<EventsResponse?>()
    val finishedEvents: LiveData<EventsResponse?> = _finishedEvents

    private val _errorMessage = MutableLiveData<String?>()
    val errorMessage: LiveData<String?> = _errorMessage

    val isLoading: LiveData<Boolean> = repository.isLoading

    init {
        fetchFinishedEvents()
    }

    fun fetchFinishedEvents() {
        repository.getEvents(active = 0, limit = 40) { response, error ->
            if (response != null) {
                _finishedEvents.postValue(response)
            } else {
                _errorMessage.postValue(error)
            }
        }
    }

    fun fetchSearchEvents(q: String) {
        repository.getSearchEvents(active = -1, q) { response, error ->
            if (response != null) {
                _finishedEvents.postValue(response)
            } else {
                _errorMessage.postValue(error)
            }
        }
    }

    fun clearErrorMessage() {
        _errorMessage.postValue(null)
    }
}