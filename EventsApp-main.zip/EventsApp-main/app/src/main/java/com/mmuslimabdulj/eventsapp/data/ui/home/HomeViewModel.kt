package com.mmuslimabdulj.eventsapp.data.ui.home

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.mmuslimabdulj.eventsapp.data.repository.EventsRepository
import com.mmuslimabdulj.eventsapp.data.response.EventsResponse

class HomeViewModel(private val repository: EventsRepository) : ViewModel() {

    private val _activeEvents = MutableLiveData<EventsResponse?>()
    val activeEvents: LiveData<EventsResponse?> = _activeEvents

    private val _finishedEvents = MutableLiveData<EventsResponse?>()
    val finishedEvents: LiveData<EventsResponse?> = _finishedEvents

    private val _errorMessage = MutableLiveData<String?>()
    val errorMessage: LiveData<String?> = _errorMessage

    val isLoading: LiveData<Boolean> = repository.isLoading

    init {
        fetchActiveEvents()
        fetchFinishedEvents()
    }

    fun fetchActiveEvents() {
        repository.getEvents(active = 1, limit = 5) { response, error ->
            if (response != null) {
                _activeEvents.postValue(response)
            } else {
                _errorMessage.postValue(error)
            }
        }
    }

    fun fetchFinishedEvents() {
        repository.getEvents(active = 0, limit = 5) { response, error ->
            if (response != null) {
                _finishedEvents.postValue(response)
            } else {
                _errorMessage.postValue(error)
            }
        }
    }

    fun clearErrorMessage() {
        _errorMessage.postValue(null)
    }
}