# Events App

Events App adalah proyek submission Dicoding yang gunanya untuk mengetahui info terbaru mengenai event-event yang ada di Dicoding. Dari mulai yang akan datang hingga yang sudah selesai.

## Fitur

- **Lihat Event Terbaru**: Pengguna dapat melihat daftar event terbaru yang akan datang.
- **Lihat Event Selesai**: Pengguna dapat melihat daftar event yang sudah selesai.
- **Detail Event**: Pengguna dapat melihat detail dari setiap event.
- **Mencari Event**: Pengguna dapat mencari event.

## Instalasi

1. Clone repositori ini:
    ```bash
    git clone https://github.com/muhmuslimabdulj/EventsApp.git
    ```
2. Buka proyek di Android Studio.
3. Jalankan aplikasi di emulator atau perangkat fisik.

## Penggunaan

1. Buka aplikasi Events App.
2. Pilih tab untuk melihat event yang akan datang atau yang sudah selesai.
3. Klik pada event untuk melihat detailnya.

## Screenshot

Berikut adalah beberapa screenshot dari aplikasi:

![Screenshot 1](./screenshot/EA-1.png)
![Screenshot 2](./screenshot/EA-2.png)
![Screenshot 3](./screenshot/EA-3.png)
![Screenshot 4](./screenshot/EA-4.png)

## Dependency dan Plugins

Proyek ini menggunakan beberapa dependency dan plugins yang didefinisikan dalam file `build.gradle.kts` di level proyek dan modul.

### Dependency

Dependency utama yang digunakan dalam proyek ini meliputi:

- **AndroidX Core**: `implementation("androidx.core:core-ktx:1.15.0")`
- **AppCompat**: `implementation("androidx.appcompat:appcompat:1.7.0")`
- **Material Design**: `implementation("com.google.android.material:material:1.12.0")`
- **ConstraintLayout**: `implementation("androidx.constraintlayout:constraintlayout:2.2.0")`
- **Lifecycle ViewModel KTX**: `implementation("androidx.lifecycle:lifecycle-viewmodel-ktx:2.8.7")`
- **LiveData KTX**: `implementation("androidx.lifecycle:lifecycle-livedata-ktx:2.8.7")`
- **Navigation Fragment KTX**: `implementation("androidx.navigation:navigation-fragment-ktx:2.8.7")`
- **Navigation UI KTX**: `implementation("androidx.navigation:navigation-ui-ktx:2.8.7")`
- **Glide**: `implementation("com.github.bumptech.glide:glide:4.16.0")`
- **Retrofit**: `implementation("com.squareup.retrofit2:retrofit:2.11.0")`
- **Gson Converter**: `implementation("com.squareup.retrofit2:converter-gson:2.11.0")`
- **Logging Interceptor**: `implementation("com.squareup.okhttp3:logging-interceptor:4.12.0")`
- **Koin Android**: `implementation("io.insert-koin:koin-android:3.5.0")`
- **Activity KTX**: `implementation("androidx.activity:activity-ktx:1.10.0")`
- **JUnit**: `testImplementation("junit:junit:4.13.2")`
- **AndroidX Test**: 
  - `androidTestImplementation("androidx.test.ext:junit:1.2.1")`
  - `androidTestImplementation("androidx.test.espresso:espresso-core:3.6.1")`

### Plugins

Plugins yang digunakan dalam proyek ini meliputi:

- **Android Application Plugin**: `id("com.android.application") version "8.8.1"`
- **Kotlin Android Plugin**: `id("org.jetbrains.kotlin.android") version "2.0.0"`

### Konfigurasi Build

Konfigurasi build didefinisikan dalam file `build.gradle.kts` di modul `app`:

- **Namespace**: `namespace = "com.mmuslimabdulj.eventsapp"`
- **Compile SDK**: `compileSdk = 35`
- **Default Config**:
  - `applicationId = "com.mmuslimabdulj.eventsapp"`
  - `minSdk = 24`
  - `targetSdk = 35`
  - `versionCode = 1`
  - `versionName = "1.0"`
- **Build Types**: Konfigurasi untuk build type `release`.
- **Build Features**: Mengaktifkan `viewBinding` dan `buildConfig`.
- **Compile Options**: Mengatur kompatibilitas Java.
- **Kotlin Options**: Mengatur target JVM untuk Kotlin.
